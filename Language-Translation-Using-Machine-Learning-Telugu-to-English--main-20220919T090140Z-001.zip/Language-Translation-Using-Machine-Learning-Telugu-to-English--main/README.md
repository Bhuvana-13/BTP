# Language-Translation-Using-Machine-Learning-Telugu-to-English-

The primary objective of this study was to build a language translation model that uses 
machine learning to translate from Telugu to English. As many studies have focused on the 
English language and other European languages in the past, However, there aren't any 
existing studies done on the Telugu language. So, the Telugu language has been chosen for 
this research. The neural network architecture used for this research, that made this project 
success, is by using Transformers for language translation. It translates own sentences of the 
Telugu language into the English. Moreover, in this research the language translation using 
Transformer model is providing a bit better result when compared to Google Translator from 
(Telugu to English). The training time, the model took to train the dataset is almost 12.5 hours. 
And the accuracy of the translation is quite good. However, there are few drawbacks in the 
translation, this can be eradicated by researching further.



The Entire Documentation for this project can be found in https://www.researchgate.net/publication/362105712_Language_Translation_using_Machine_Learning
